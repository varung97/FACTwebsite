#ifndef WRAPPER_H
#define WRAPPER_H
#include <string>
using namespace std;

void nexReader(string s);
void nexGen(int k, int n, int type);
#endif
